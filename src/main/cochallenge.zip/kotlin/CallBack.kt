interface CallBack {
    fun tampilkanHasil(result: String)
}